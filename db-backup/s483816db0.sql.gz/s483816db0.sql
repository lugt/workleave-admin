-- phpMyAdmin SQL Dump
-- version 3.4.9
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2024 年 10 月 15 日 10:30
-- 服务器版本: 5.5.20
-- PHP 版本: 5.3.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `s483816db0`
--

-- --------------------------------------------------------

--
-- 表的结构 `bwfx_leave`
--

CREATE TABLE IF NOT EXISTS `bwfx_leave` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `class` tinyint(2) NOT NULL,
  `start` int(11) NOT NULL,
  `end` int(11) NOT NULL,
  `type` int(11) NOT NULL DEFAULT '1',
  `state` smallint(6) NOT NULL DEFAULT '100',
  `reason` text,
  `pos` tinytext,
  `apply` mediumint(9) NOT NULL DEFAULT '0',
  `aptime` int(11) NOT NULL,
  `exam` int(11) NOT NULL,
  `extime` int(11) NOT NULL,
  `fire` int(11) NOT NULL,
  `fitime` int(11) NOT NULL,
  `memo` text,
  `lid` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lid` (`lid`),
  KEY `class` (`class`),
  KEY `start` (`start`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1028 ;

--
-- 转存表中的数据 `bwfx_leave`
--

INSERT INTO `bwfx_leave` (`id`, `name`, `class`, `start`, `end`, `type`, `state`, `reason`, `pos`, `apply`, `aptime`, `exam`, `extime`, `fire`, `fitime`, `memo`, `lid`) VALUES
(1021, '网横冲', 11, 1456243260, 1456329540, 1, 100, '学生会开会', '322', 1, 1456327262, 322, 0, 0, 0, '', 2016022423212818),
(1022, '网横冲', 11, 1456243260, 1456329540, 1, 300, '学生会开会', '322', 1, 1456327522, 1, 1456461688, 0, 0, '', 2016022423252420),
(1023, '朱佳慧 许苗苗', 53, 1456376400, 1456415940, 1, 300, 's1', '322', 1, 1456329480, 1, 1456407001, 0, 0, '', 2016022423583265),
(1024, 'hhh', 11, 1456894800, 1456934340, 1, 100, 's3', 'hhh', 1, 1456742763, 0, 0, 0, 0, 'hhhh', 2016022918462430),
(1025, 'hhh', 11, 1456808400, 1456847940, 1, 300, 's3', 'hhh', 1, 1456742797, 1, 1456743371, 0, 0, 'hhhh', 2016022918462285),
(1026, 'hhh', 11, 1456549200, 1456588740, 1, 100, 's3', 'jj', 1, 1456743604, 0, 0, 0, 0, 'jjjj', 2016022919003197),
(1027, 'hhh', 11, 1456808400, 1456847940, 1, 300, 's3', 'hhh', 3, 1456747631, 1, 1456749993, 0, 0, 'hhhh', 2016022920071338);

-- --------------------------------------------------------

--
-- 表的结构 `bwfx_teacher`
--

CREATE TABLE IF NOT EXISTS `bwfx_teacher` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `usn` tinytext NOT NULL,
  `pss` tinytext NOT NULL,
  `name` tinytext,
  `title` tinytext,
  `priv` tinytext,
  `state` int(11) NOT NULL,
  `sess` tinytext,
  `memo` tinytext,
  `phone` tinytext,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `bwfx_teacher`
--

INSERT INTO `bwfx_teacher` (`uid`, `usn`, `pss`, `name`, `title`, `priv`, `state`, `sess`, `memo`, `phone`) VALUES
(1, 'lugt', 'THVndDEy', '鲁冠廷', '学生会主席', 'leave,auth,unreg', 10, 'APL2016/02/291456758574', NULL, '18611823550'),
(2, 'lugtj', 'MTIzNDU=', '李叶华', '校本课程', '', 10, 'APL2016/02/291456747320', NULL, '12455558888'),
(3, 'lugts', 'MTIzNDU=', '李叶亩', '校本课程', 'leave', 10, 'APL2016/02/291456748727', NULL, '12455558889');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
